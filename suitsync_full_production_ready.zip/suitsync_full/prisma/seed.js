const prisma = require('../server/prismaClient');

async function main() {
  // Clear data
  await prisma.appointment.deleteMany();
  await prisma.alteration.deleteMany();
  await prisma.partyMember.deleteMany();
  await prisma.party.deleteMany();
  await prisma.customer.deleteMany();

  // Seed demo entries
  const customer = await prisma.customer.create({
    data: { firstName:'John', lastName:'Doe', email:'john@example.com', phone:'555-1234' }
  });
  const party = await prisma.party.create({
    data: { name:'Doe Wedding', eventDate:new Date(), customerId:customer.id }
  });
  await prisma.partyMember.createMany({
    data: [
      { name:'John Doe', partyId:party.id },
      { name:'Jane Doe', partyId:party.id }
    ]
  });
  await prisma.appointment.create({
    data: { partyId:party.id, dateTime:new Date(), durationMinutes:60 }
  });
  await prisma.alteration.create({
    data: {
      partyId:party.id,
      notes:'Shorten sleeves',
      timeSpentMinutes:30,
      garmentType:'Jacket'
    }
  });

  console.log('✅ Demo data seeded');
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});
