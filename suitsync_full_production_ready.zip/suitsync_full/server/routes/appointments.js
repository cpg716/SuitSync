const router = require('express').Router();
const prisma = require('../prismaClient');

router.get('/', async (req, res) => {
  res.json(await prisma.appointment.findMany());
});

router.post('/', async (req, res) => {
  const appt = await prisma.appointment.create({ data: req.body });
  res.json(appt);
});

module.exports = router;
