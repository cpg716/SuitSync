const router = require('express').Router();
const prisma = require('../prismaClient');
const { upsertCustomer, createSale, addLineItem } = require('../lightspeedClient');

router.get('/', async (req, res) => {
  res.json(await prisma.alteration.findMany());
});

router.post('/', async (req, res) => {
  const alt = await prisma.alteration.create({ data: req.body });
  try {
    const party = await prisma.party.findUnique({ where:{ id: alt.partyId }, include:{ customer:true } });
    const lsCust = await upsertCustomer(party.customer);
    const lsSale = await createSale(party, lsCust);
    await addLineItem(lsSale, {
      serviceId: 1,
      fee: 0,
      notes: alt.notes,
      timeSpent: alt.timeSpentMinutes
    });
  } catch (e) { console.error(e); }
  res.json(alt);
});

module.exports = router;
