const router = require('express').Router();
const prisma = require('../prismaClient');
const { upsertCustomer, createSale } = require('../lightspeedClient');

router.get('/', async (req, res) => {
  res.json(await prisma.party.findMany());
});

router.post('/', async (req, res) => {
  const party = await prisma.party.create({ data: req.body });
  try {
    const cust = await prisma.customer.findUnique({ where:{ id: party.customerId } });
    const lsCust = await upsertCustomer(cust);
    await createSale(party, lsCust);
  } catch (e) { console.error(e); }
  res.json(party);
});

module.exports = router;
