const express = require('express');
const router = express.Router();

router.post('/lightspeed', express.raw({ type: 'application/json' }), (req, res) => {
  res.sendStatus(200);
});

module.exports = router;
