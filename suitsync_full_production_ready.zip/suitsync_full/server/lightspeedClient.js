const axios = require('axios');
const baseURL = \`https://\${process.env.LS_DOMAIN}/api/2.0\`;
const client = axios.create({
  baseURL,
  headers: { Authorization: \`Bearer \${process.env.LS_TOKEN}\` }
});

module.exports = {
  client,
  async ensureWebhooks() {
    // register hooks...
  },
  async upsertCustomer() { /*...*/ },
  async createSale() { /*...*/ },
  async addLineItem() { /*...*/ },
};
