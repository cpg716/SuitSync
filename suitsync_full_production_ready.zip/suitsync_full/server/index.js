require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const parties = require('./routes/parties');
const alterations = require('./routes/alterations');
const appointments = require('./routes/appointments');
const webhooks = require('./webhooks');
const { ensureWebhooks } = require('./lightspeedClient');
const app = express();

app.use(bodyParser.json());
app.use('/api/parties', parties);
app.use('/api/alterations', alterations);
app.use('/api/appointments', appointments);
app.use('/webhooks', webhooks);

ensureWebhooks().then(() => {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log('Server listening on', PORT));
});
